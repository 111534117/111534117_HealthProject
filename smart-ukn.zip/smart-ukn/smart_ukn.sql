-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主機： 127.0.0.1
-- 產生時間： 2026-08-11 09:01:52
-- 伺服器版本： 10.4.32-MariaDB
-- PHP 版本： 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `smart_ukn`
--

-- --------------------------------------------------------

--
-- 資料表結構 `checklist_items`
--

CREATE TABLE `checklist_items` (
  `item_id` int(11) NOT NULL COMMENT '清單唯一碼',
  `business_name` varchar(100) NOT NULL COMMENT '行政業務名稱',
  `steps_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '辦理步驟 (JSON 陣列格式)' CHECK (json_valid(`steps_json`)),
  `required_docs` text DEFAULT NULL COMMENT '應備文件說明',
  `office_hours` varchar(100) DEFAULT NULL COMMENT '辦公服務時間'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='行政流程指引清單';

--
-- 傾印資料表的資料 `checklist_items`
--

INSERT INTO `checklist_items` (`item_id`, `business_name`, `steps_json`, `required_docs`, `office_hours`) VALUES
(1, '學生停修申請', '[\"1. 填寫線上停修申請單\", \"2. 列印申請表並經授課教師簽名同意\", \"3. 送交至教務處課務組\"]', '停修申請表(須教師簽章)、學生證正本', '週一至週五 08:30 - 17:00'),
(2, '補發學生證', '[\"1. 登入教務系統掛失\", \"2. 至出納組自動繳費機繳交工本費\", \"3. 持繳費收據至註冊組辦理補發\"]', '身分證正本、工本費收據、兩吋大頭照電子檔', '週一至週五 09:00 - 16:30'),
(3, '學分抵免', '[\"1. 確認自身符合抵免資格\", \"2. 準備原學校/原系所之歷年成績單\", \"3. 填寫抵免單並由所屬系所初審\", \"4. 將核准單送交教務處複審\"]', '原校/原系歷年成績單正本、相關課程大綱', '開學前兩週內 08:30 - 17:00');

-- --------------------------------------------------------

--
-- 資料表結構 `course_map`
--

CREATE TABLE `course_map` (
  `course_id` varchar(20) NOT NULL COMMENT '課程代碼',
  `course_name` varchar(100) NOT NULL COMMENT '課程名稱',
  `credits` int(11) NOT NULL COMMENT '學分數',
  `prerequisite_id` varchar(20) DEFAULT NULL COMMENT '先修課程 ID',
  `is_required` tinyint(1) NOT NULL DEFAULT 1 COMMENT '是否為必修 (1=必修, 0=選修)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='課程地圖及先修關係表';

--
-- 傾印資料表的資料 `course_map`
--

INSERT INTO `course_map` (`course_id`, `course_name`, `credits`, `prerequisite_id`, `is_required`) VALUES
('CS101', '計算機概論', 3, NULL, 1),
('CS102', '程式設計(一)', 3, 'CS101', 1),
('CS201', '資料結構', 3, 'CS102', 1),
('EN101', '基礎英文', 2, NULL, 1),
('GE101', '大學之道', 2, NULL, 0);

-- --------------------------------------------------------

--
-- 資料表結構 `knowledge_base`
--

CREATE TABLE `knowledge_base` (
  `id` int(11) NOT NULL,
  `keyword` varchar(255) NOT NULL,
  `official_term` varchar(255) DEFAULT '',
  `content` text NOT NULL,
  `doc_name` varchar(255) NOT NULL,
  `page` int(11) DEFAULT 1,
  `url` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `knowledge_base`
--

INSERT INTO `knowledge_base` (`id`, `keyword`, `official_term`, `content`, `doc_name`, `page`, `url`) VALUES
(1, '棄修', '停修', '關於「停修」的辦理規定：學生應於校曆規定之申請期限內提出申請，經導師及系所主管核章後送交教務處辦理。逾期不受理。', '康寧大學學生學則.pdf', 12, 'https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw'),
(2, '英文抵免', '語言證照抵免', '關於「語言證照抵免」：凡通過全民英檢中高級或同等多益成績者，得於入學第一學期申請抵免大一英文課程。', '康寧大學抵免學分辦法.pdf', 5, 'https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw'),
(3, '請假規定', '學生請假規定', '關於「學生請假」：病假需附三日內醫院證明，三天以上需經系主任核准，並於請假系統完成線上簽核。', '康寧大學學生請假規則.pdf', 3, 'https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw'),
(4, '請假規定', '學生請假辦法', '學生因故不能出席各項課業，須於事前或事後規定期限內辦理請假手續。假別分為公假、事假、病假、喪假、產前假、娩假、流產假及陪產假等。請假手續須透過學生教務系統線上申請，並依規定檢附證明文件送核。', '學生請假辦法.pdf', 1, 'https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw'),
(5, '英文抵免', '學分抵免辦法', '凡通過校外英檢測驗（如 TOEIC 達到指定門檻）或具備同等學力者，得於入學第一學期規定期限內，檢附成績單或證書正影本，申請抵免大一英文或相關外語課程學分。', '學生抵免學分要點.pdf', 2, 'https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw'),
(6, '棄修流程', '停修課程辦理規定', '學生於加退選截止後，因特殊原因無法繼續修習某門課程，得於學期第 10-12 週申請停修（每學期以科為限）。停修課程仍須登記於歷年成績單，但成績欄註記「停修」，不計入該學期學分數計算。', '康寧大學學生學則.pdf', 15, 'https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw'),
(7, '獎懲辦法', '學生獎懲辦法', '為鼓勵學生向上及維持校規，設有嘉獎、小功、大功等獎勵；違反校規者則視情節輕重給予警告、申誡、小過、大過、留校察看或退學處分。學生對獎懲有異議者，得於收到通知後依規定提出申訴。', '學生獎懲辦法.pdf', 3, 'https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw'),
(8, '曠課', '學生扣考與出勤規定', '學生無故未出席課程視為曠課，每曠課一小時扣減總成績特定分數。一學期中某科曠課時數達該科授課總時數三分之一以上者，該科目不得參加期末考試（即扣考），成績以零分計算。', '康寧大學學生學則.pdf', 18, 'https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw'),
(9, '棄修', '學生停修課程', '學生於加退選後因特殊事故無法繼續修習科目，得申請停修課程（棄修）。停修以二科為限，且停修後修習學分數不得低於最低應修學分數。', '康寧大學學生選課辦法.pdf', 3, 'https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw'),
(10, '英文抵免', '英文能力檢定抵免', '凡通過指定之英語能力檢定標準（如 TOEIC、GEPT）者，得申請抵免大一英文或通識英文課程學分。', '康寧大學抵免學分要點.pdf', 2, 'https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw'),
(11, '請假', '學生請假規定', '學生因故不能出席課程者，應依規定填寫假單並檢附相關證明檔辦理請假，事假需事先辦理，病假得於三日內補辦。', '康寧大學學生請假規則.pdf', 1, 'https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw');

-- --------------------------------------------------------

--
-- 資料表結構 `student_credits`
--

CREATE TABLE `student_credits` (
  `credit_id` int(11) NOT NULL COMMENT '成績紀錄唯一碼',
  `student_id` varchar(20) NOT NULL COMMENT '學號',
  `course_id` varchar(20) NOT NULL COMMENT '課程代碼',
  `score` decimal(5,2) DEFAULT NULL COMMENT '成績分數',
  `is_passed` tinyint(1) NOT NULL COMMENT '是否通過 (1=通過, 0=未通過)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='學生成績與學分紀錄表';

--
-- 傾印資料表的資料 `student_credits`
--

INSERT INTO `student_credits` (`credit_id`, `student_id`, `course_id`, `score`, `is_passed`) VALUES
(1, 'S112001', 'CS101', 85.00, 1),
(2, 'S112001', 'CS102', 55.00, 0),
(3, 'S112002', 'CS101', 92.50, 1),
(4, 'S112002', 'GE101', 88.00, 1),
(5, 'S112003', 'CS101', 60.00, 1);

-- --------------------------------------------------------

--
-- 資料表結構 `synonym_dictionary`
--

CREATE TABLE `synonym_dictionary` (
  `synonym_id` int(11) NOT NULL COMMENT '字典項目唯一碼',
  `user_keyword` varchar(50) NOT NULL COMMENT '使用者俗稱/口語',
  `official_term` varchar(50) NOT NULL COMMENT '官方標準用語',
  `category` varchar(50) NOT NULL COMMENT '分類標籤 (如：課務、學籍等)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='智慧檢索同義詞字典';

--
-- 傾印資料表的資料 `synonym_dictionary`
--

INSERT INTO `synonym_dictionary` (`synonym_id`, `user_keyword`, `official_term`, `category`) VALUES
(1, '棄修', '停修', '課務'),
(2, '二一', '學業退學', '學籍'),
(3, '重修', '再次修習', '課務'),
(4, '請假', '學生請假', '學務'),
(5, '當掉', '成績不及格', '課務');

-- --------------------------------------------------------

--
-- 資料表結構 `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL COMMENT '使用者唯一識別碼',
  `role` enum('學生','家長','老師','管理員') NOT NULL COMMENT '使用者角色',
  `student_id` varchar(20) DEFAULT NULL COMMENT '學號 (供學生或其相關人員使用)',
  `parent_id` varchar(20) DEFAULT NULL COMMENT '家長編號',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT '建立時間'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系統使用者資料表';

--
-- 傾印資料表的資料 `users`
--

INSERT INTO `users` (`user_id`, `role`, `student_id`, `parent_id`, `created_at`) VALUES
(1, '學生', 'S112001', NULL, '2026-08-06 01:50:30'),
(2, '學生', 'S112002', NULL, '2026-08-06 01:50:30'),
(3, '學生', 'S112003', NULL, '2026-08-06 01:50:30'),
(4, '家長', NULL, 'P112001', '2026-08-06 01:50:30'),
(5, '老師', NULL, NULL, '2026-08-06 01:50:30'),
(6, '管理員', NULL, NULL, '2026-08-06 01:50:30');

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `checklist_items`
--
ALTER TABLE `checklist_items`
  ADD PRIMARY KEY (`item_id`);

--
-- 資料表索引 `course_map`
--
ALTER TABLE `course_map`
  ADD PRIMARY KEY (`course_id`),
  ADD KEY `prerequisite_id` (`prerequisite_id`);

--
-- 資料表索引 `knowledge_base`
--
ALTER TABLE `knowledge_base`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `student_credits`
--
ALTER TABLE `student_credits`
  ADD PRIMARY KEY (`credit_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `course_id` (`course_id`);

--
-- 資料表索引 `synonym_dictionary`
--
ALTER TABLE `synonym_dictionary`
  ADD PRIMARY KEY (`synonym_id`);

--
-- 資料表索引 `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `student_id` (`student_id`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `checklist_items`
--
ALTER TABLE `checklist_items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '清單唯一碼', AUTO_INCREMENT=4;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `knowledge_base`
--
ALTER TABLE `knowledge_base`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `student_credits`
--
ALTER TABLE `student_credits`
  MODIFY `credit_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '成績紀錄唯一碼', AUTO_INCREMENT=6;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `synonym_dictionary`
--
ALTER TABLE `synonym_dictionary`
  MODIFY `synonym_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '字典項目唯一碼', AUTO_INCREMENT=6;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '使用者唯一識別碼', AUTO_INCREMENT=7;

--
-- 已傾印資料表的限制式
--

--
-- 資料表的限制式 `course_map`
--
ALTER TABLE `course_map`
  ADD CONSTRAINT `course_map_ibfk_1` FOREIGN KEY (`prerequisite_id`) REFERENCES `course_map` (`course_id`) ON DELETE SET NULL;

--
-- 資料表的限制式 `student_credits`
--
ALTER TABLE `student_credits`
  ADD CONSTRAINT `student_credits_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`student_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `student_credits_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `course_map` (`course_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
