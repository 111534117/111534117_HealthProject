from flask import Flask, request, jsonify
from flask_cors import CORS
import mysql.connector
import os
import sys
import json

# 設定 Windows 終端輸出為 UTF-8
if sys.stdout and hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
if sys.stderr and hasattr(sys.stderr, 'reconfigure'):
    try:
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

# ==========================================
# Smart UKN 康寧大學智慧校園服務平台 - 後端核心
# ==========================================

app = Flask(
    __name__,
    static_folder="static",
    static_url_path=""
)

# 允許跨網域與跨裝置請求
CORS(app)

# ==========================================
# 1. 資料庫連線配置
# ==========================================

DB_CONFIG = {
    "host": os.getenv("DB_HOST", "127.0.0.1"),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", ""),
    "database": os.getenv("DB_NAME", "smart_ukn"),
    "port": int(os.getenv("DB_PORT", 3306)),
    "charset": "utf8mb4"
}

# ==========================================
# 2. 示範模式資料庫 (Demo Fallback Storage)
#    當 MySQL 離線或尚未啟動時無縫接管，保證系統100%正常展示
# ==========================================

DEMO_KNOWLEDGE_BASE = [
    {
        "id": 1,
        "keyword": "棄修",
        "official_term": "停修",
        "content": "學生於加退選截止後，因特殊原因無法繼續修習某門課程，得於學期第 10-12 週申請停修（每學期以 2 科為限）。停修課程仍須登記於歷年成績單，但成績欄註記「停修」，不計入該學期學分數計算，且停修後學分數不得低於該學期最低應修學分。",
        "doc_name": "康寧大學學生學則.pdf",
        "page": 12,
        "url": "https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw"
    },
    {
        "id": 2,
        "keyword": "英文抵免",
        "official_term": "語言證照抵免",
        "content": "凡通過全民英檢中高級、多益(TOEIC) 550 分以上或同等國際英語檢定標準者，得於入學第一學期規定期限內，檢附成績單與證書正本向教務處申請抵免大一英文或通識外語學分。",
        "doc_name": "康寧大學抵免學分辦法.pdf",
        "page": 5,
        "url": "https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw"
    },
    {
        "id": 3,
        "keyword": "請假規定",
        "official_term": "學生請假辦法",
        "content": "學生因故不能出席課業活動，須於事前或事後規定期限內辦理請假。假別包含公假、事假、病假、喪假及生理假等。病假須檢附三日內就醫證明，三天以上須經系主任簽核，所有請假程序均需透過學生教務系統線上完成申請與核准。",
        "doc_name": "學生請假辦法.pdf",
        "page": 3,
        "url": "https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw"
    },
    {
        "id": 4,
        "keyword": "二一退學",
        "official_term": "學業退學規定",
        "content": "學士班學生單一學期學業成績不及格科目之學分數，達該學期修習學分總數二分之一者，依校規予以學業輔導；若連續兩學期或累計達校規規定之學業成績二分之一不及格者，應予退學處分（特殊身分或延修生另依相關條例辦理）。",
        "doc_name": "康寧大學學生學則.pdf",
        "page": 24,
        "url": "https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw"
    },
    {
        "id": 5,
        "keyword": "獎懲辦法",
        "official_term": "學生獎懲辦法",
        "content": "本校學生之獎勵分為嘉獎、小功、大功及特殊獎勵；懲處分為申誡、小過、大過、留校察看及退學。學生對於學校所為之懲處認有違法或不當致損害其權益者，得於收到處分通知書之次日起十日內向學生申訴評議委員會提出申訴。",
        "doc_name": "康寧大學學生獎懲辦法.pdf",
        "page": 3,
        "url": "https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw"
    },
    {
        "id": 6,
        "keyword": "曠課扣考",
        "official_term": "學生出勤與扣考規定",
        "content": "學生未經請假或請假未准而缺席者視為曠課。某一科目缺課（含請假及曠課）時數達該科目全學期授課總時數三分之一者，不得參加該科目之學期考試，該科目學期成績以零分計算。",
        "doc_name": "康寧大學學生學則.pdf",
        "page": 18,
        "url": "https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw"
    },
    {
        "id": 7,
        "keyword": "補發學生證",
        "official_term": "學生證遺失補發流程",
        "content": "學生證遺失時，應即登入學生教務資訊系統辦理線上掛失，並至出納組自動化繳費機繳納工本費（新台幣 150 元），攜帶繳費收據與身分證明文件至教務處註冊組辦理補發，約 3 個工作天即可領取新卡。",
        "doc_name": "康寧大學教務處學生證管理要點.pdf",
        "page": 2,
        "url": "https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw"
    }
]

DEMO_SYNONYMS = [
    {"synonym_id": 1, "user_keyword": "棄修", "official_term": "停修", "category": "課務"},
    {"synonym_id": 2, "user_keyword": "退選", "official_term": "停修", "category": "課務"},
    {"synonym_id": 3, "user_keyword": "二一", "official_term": "學業退學", "category": "學籍"},
    {"synonym_id": 4, "user_keyword": "重修", "official_term": "再次修習", "category": "課務"},
    {"synonym_id": 5, "user_keyword": "請假", "official_term": "學生請假辦法", "category": "學務"},
    {"synonym_id": 6, "user_keyword": "當掉", "official_term": "成績不及格", "category": "課務"},
    {"synonym_id": 7, "user_keyword": "英文免修", "official_term": "語言證照抵免", "category": "教務"},
    {"synonym_id": 8, "user_keyword": "擋修", "official_term": "先修科目未通過", "category": "課務"}
]

DEMO_CHECKLISTS = [
    {
        "item_id": 1,
        "business_name": "學生課程停修（棄修）申請",
        "category": "課務組",
        "steps_json": [
            "登入學生資訊系統填寫「停修申請單」",
            "列印紙本申請表並請授課教師簽章同意",
            "送交系所導師與系主任核章",
            "於規定期限前送交教務處課務組完成審核"
        ],
        "required_docs": "停修申請表（需任課老師簽名）、學生證正本",
        "office_hours": "週一至週五 08:30 - 17:00 (行政大樓教務處)"
    },
    {
        "item_id": 2,
        "business_name": "學生證遺失補發申請",
        "category": "註冊組",
        "steps_json": [
            "登入教務系統進行線上卡片掛失",
            "至行政大樓自動繳費機繳交補發工本費 150 元",
            "持繳費收據及身分證明至註冊組辦理",
            "3 個工作天後憑收據至註冊組領取新學生證"
        ],
        "required_docs": "身分證或健保卡正本、繳費收據、2吋大頭照電子檔",
        "office_hours": "週一至週五 09:00 - 16:30 (行政大樓註冊組)"
    },
    {
        "item_id": 3,
        "business_name": "外語證照 / 學分抵免申請",
        "category": "註冊組",
        "steps_json": [
            "確認符合抵免條件（如多益 550 分以上或全民英檢中高級）",
            "備妥成績單或證書正本與影本",
            "填寫學分抵免申請表並由所屬系所初審",
            "於開學兩週內送交教務處註冊組複審核定"
        ],
        "required_docs": "語言檢定證書正影本、歷年成績單、學分抵免申請表",
        "office_hours": "開學前兩週內 08:30 - 17:00 (教務處)"
    },
    {
        "item_id": 4,
        "business_name": "學生病假與公假線上請假流程",
        "category": "學務處",
        "steps_json": [
            "事假須事前於線上請假系統提出申請",
            "病假須於返校 3 日內登入系統補辦並上傳就醫證明檔",
            "公假須檢附公函或主辦單位指派證明",
            "經導師及系輔導人員線上審核通過即生效"
        ],
        "required_docs": "三日內診斷證明或收據電子檔（病假）、派遣公文（公假）",
        "office_hours": "線上系統 24 小時開放受理"
    }
]

DEMO_COURSES = [
    {
        "course_id": "CS101",
        "course_name": "計算機概論",
        "credits": 3,
        "prerequisite_id": None,
        "prerequisite_name": None,
        "is_required": 1,
        "semester": "大一上",
        "description": "計算機科學基礎、硬體架構、作業系統與網路概論。"
    },
    {
        "course_id": "CS102",
        "course_name": "程式設計(一)",
        "credits": 3,
        "prerequisite_id": "CS101",
        "prerequisite_name": "計算機概論",
        "is_required": 1,
        "semester": "大一下",
        "description": "Python 與 C 語言基礎邏輯、變數、迴圈與函式設計。"
    },
    {
        "course_id": "CS201",
        "course_name": "資料結構",
        "credits": 3,
        "prerequisite_id": "CS102",
        "prerequisite_name": "程式設計(一)",
        "is_required": 1,
        "semester": "大二上",
        "description": "陣列、鏈結串列、堆疊、佇列、樹狀與圖形演算法。"
    },
    {
        "course_id": "CS202",
        "course_name": "物件導向程式設計",
        "credits": 3,
        "prerequisite_id": "CS102",
        "prerequisite_name": "程式設計(一)",
        "is_required": 1,
        "semester": "大二下",
        "description": "類別、物件、繼承、多型與 Java/C++ 設計模式。"
    },
    {
        "course_id": "CS301",
        "course_name": "演算法分析",
        "credits": 3,
        "prerequisite_id": "CS201",
        "prerequisite_name": "資料結構",
        "is_required": 1,
        "semester": "大三上",
        "description": "時間複雜度、分治法、貪婪演算法、動態規劃。"
    },
    {
        "course_id": "CS302",
        "course_name": "資料庫系統概論",
        "credits": 3,
        "prerequisite_id": "CS201",
        "prerequisite_name": "資料結構",
        "is_required": 1,
        "semester": "大三上",
        "description": "關聯式資料庫、SQL 語法、正規化與 MySQL 實作。"
    },
    {
        "course_id": "CS401",
        "course_name": "畢業專題研討",
        "credits": 3,
        "prerequisite_id": "CS302",
        "prerequisite_name": "資料庫系統概論",
        "is_required": 1,
        "semester": "大四上",
        "description": "綜合資訊系統開發、AI 應用整合與專題報告展示。"
    },
    {
        "course_id": "EN101",
        "course_name": "基礎英文",
        "credits": 2,
        "prerequisite_id": None,
        "prerequisite_name": None,
        "is_required": 1,
        "semester": "大一上",
        "description": "大一基礎外語聽說讀寫與學術閱讀。"
    },
    {
        "course_id": "GE101",
        "course_name": "大學之道與倫理",
        "credits": 2,
        "prerequisite_id": None,
        "prerequisite_name": None,
        "is_required": 0,
        "semester": "大一上",
        "description": "校園生活適應、生命教育與職場倫理。"
    }
]

# ==========================================
# 3. 資料庫輔助連線函式
# ==========================================

def get_db_connection():
    """嘗試取得 MySQL 連線，若失敗拋出異常以供降級處理"""
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        if conn.is_connected():
            return conn
    except Exception:
        return None
    return None

def is_db_available():
    """檢測 MySQL 是否在線"""
    conn = get_db_connection()
    if conn:
        conn.close()
        return True
    return False

# ==========================================
# 4. 前端頁面路由
# ==========================================

@app.route("/")
def index():
    return app.send_static_file("index.html")

@app.route("/admin")
def admin_page():
    return app.send_static_file("admin.html")

# ==========================================
# 5. 健康檢查與系統狀態 API
# ==========================================

@app.route("/api/health", methods=["GET"])
def health_check():
    db_online = is_db_available()
    return jsonify({
        "status": "online",
        "database": "connected" if db_online else "fallback_demo_mode",
        "db_mode": "MySQL 8.x / MariaDB" if db_online else "內建示範資料引擎 (Demo Storage)",
        "message": "Smart UKN 服務運作正常！" if db_online else "目前以示範資料庫模式運行，全功能可用！"
    }), 200

@app.route("/api/stats", methods=["GET"])
def get_stats():
    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT COUNT(*) as cnt FROM knowledge_base")
            rule_cnt = cursor.fetchone()["cnt"]
            
            cursor.execute("SELECT COUNT(*) as cnt FROM synonym_dictionary")
            synonym_cnt = cursor.fetchone()["cnt"]
            
            cursor.execute("SELECT COUNT(*) as cnt FROM checklist_items")
            checklist_cnt = cursor.fetchone()["cnt"]
            
            cursor.execute("SELECT COUNT(*) as cnt FROM course_map")
            course_cnt = cursor.fetchone()["cnt"]
            
            cursor.close()
            conn.close()
            return jsonify({
                "status": "success",
                "rules_count": rule_cnt,
                "synonyms_count": synonym_cnt,
                "checklists_count": checklist_cnt,
                "courses_count": course_cnt,
                "mode": "mysql"
            }), 200
        except Exception:
            if conn: conn.close()

    # Fallback to Demo Data
    return jsonify({
        "status": "success",
        "rules_count": len(DEMO_KNOWLEDGE_BASE),
        "synonyms_count": len(DEMO_SYNONYMS),
        "checklists_count": len(DEMO_CHECKLISTS),
        "courses_count": len(DEMO_COURSES),
        "mode": "demo"
    }), 200

# ==========================================
# 6. AI 智慧搜尋 API (含同義詞與流程聯動)
# ==========================================

@app.route("/api/search", methods=["GET", "POST"])
def search_knowledge():
    if request.method == "GET":
        q = request.args.get("query", "").strip()
        if not q:
            return jsonify({"status": "online", "message": "Smart UKN 搜尋 API 服務正常運作中！"}), 200
        user_query = q
    else:
        data = request.get_json(silent=True) or {}
        user_query = str(data.get("query", "")).strip()

    if len(user_query) < 1:
        return jsonify({"detail": "請輸入搜尋關鍵字"}), 400

    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor(dictionary=True)
            
            # 1. 檢查同義詞庫
            synonym_sql = "SELECT official_term FROM synonym_dictionary WHERE user_keyword = %s LIMIT 1"
            cursor.execute(synonym_sql, (user_query,))
            syn_row = cursor.fetchone()
            
            is_synonym = False
            official_term = ""
            search_key = user_query
            
            if syn_row and syn_row.get("official_term"):
                is_synonym = True
                official_term = syn_row["official_term"]
                search_key = official_term

            # 2. 搜尋校規知識庫
            sql = """
                SELECT id, keyword, official_term, content, doc_name, page, url
                FROM knowledge_base
                WHERE keyword LIKE %s
                   OR official_term LIKE %s
                   OR content LIKE %s
                   OR doc_name LIKE %s
                ORDER BY 
                    CASE 
                        WHEN keyword = %s THEN 1
                        WHEN official_term = %s THEN 2
                        WHEN keyword LIKE %s THEN 3
                        ELSE 4 
                    END
                LIMIT 5
            """
            pat = f"%{search_key}%"
            cursor.execute(sql, (pat, pat, pat, pat, search_key, search_key, pat))
            results = cursor.fetchall()

            # 3. 取得相關辦理流程清單
            chk_sql = "SELECT business_name, steps_json, required_docs, office_hours FROM checklist_items WHERE business_name LIKE %s LIMIT 1"
            cursor.execute(chk_sql, (pat,))
            chk_row = cursor.fetchone()
            
            cursor.close()
            conn.close()

            if results:
                primary = results[0]
                matched_official = official_term or primary.get("official_term") or ""
                has_synonym = bool(matched_official and matched_official != user_query)

                checklist_steps = []
                if chk_row and chk_row.get("steps_json"):
                    try:
                        checklist_steps = json.loads(chk_row["steps_json"])
                    except Exception:
                        checklist_steps = [chk_row["steps_json"]]
                else:
                    checklist_steps = [
                        "確認相關校規與申請資格",
                        "準備相關證明與表單文件",
                        "經授課教師/系主任核章後送交教務處審查"
                    ]

                return jsonify({
                    "status": "success",
                    "is_synonym_matched": has_synonym,
                    "official_term": matched_official,
                    "search_term": user_query,
                    "answer": primary.get("content") or "",
                    "source_doc": primary.get("doc_name") or "康寧大學校規規章.pdf",
                    "page_num": primary.get("page") or 1,
                    "source_url": primary.get("url") or "https://www.ukn.edu.tw/",
                    "checklist": checklist_steps,
                    "all_matches": results
                }), 200

        except Exception as e:
            if conn: conn.close()
            print("DB search error, falling back to demo:", e)

    # --------------------------------------
    # Fallback to Demo Search Engine
    # --------------------------------------
    is_synonym = False
    official_term = ""
    target_key = user_query.lower()

    # 查同義詞
    for syn in DEMO_SYNONYMS:
        if syn["user_keyword"].lower() in target_key or target_key in syn["user_keyword"].lower():
            is_synonym = True
            official_term = syn["official_term"]
            target_key = official_term.lower()
            break

    # 查知識庫
    matched = []
    for item in DEMO_KNOWLEDGE_BASE:
        kw = item["keyword"].lower()
        ot = item["official_term"].lower()
        ct = item["content"].lower()
        dn = item["doc_name"].lower()
        
        if (target_key in kw or target_key in ot or target_key in ct or target_key in dn or
            user_query.lower() in kw or user_query.lower() in ot or user_query.lower() in ct):
            matched.append(item)

    if matched:
        primary = matched[0]
        chk_steps = [
            "確認相關校規與申辦期程",
            "備妥規定期限內之證明文件",
            "依程序線上申請或送交行政單位簽核"
        ]
        for c in DEMO_CHECKLISTS:
            if target_key in c["business_name"].lower() or (official_term and official_term.lower() in c["business_name"].lower()):
                chk_steps = c["steps_json"]
                break

        return jsonify({
            "status": "success",
            "is_synonym_matched": is_synonym,
            "official_term": official_term or primary.get("official_term", ""),
            "search_term": user_query,
            "answer": primary["content"],
            "source_doc": primary["doc_name"],
            "page_num": primary["page"],
            "source_url": primary["url"],
            "checklist": chk_steps,
            "all_matches": matched
        }), 200

    # 無相符結果
    return jsonify({
        "status": "success",
        "is_synonym_matched": False,
        "official_term": "",
        "search_term": user_query,
        "answer": f"資料庫中暫無與「{user_query}」直接對應之校規條文。建議您更換搜尋字詞（如：停修、請假、抵免、學則），或洽詢教務處相關業務組別。",
        "source_doc": "康寧大學法規與教務專區",
        "page_num": "-",
        "source_url": "https://www.ukn.edu.tw/",
        "checklist": [
            "確認關鍵字拼寫或改用官方稱呼",
            "查閱學校官網最新公告規章",
            "致電教務處各承辦單位詢問"
        ],
        "all_matches": []
    }), 200

# ==========================================
# 7. 校規知識庫 CRUD API (/api/rules)
# ==========================================

@app.route("/api/rules", methods=["GET", "POST"])
def manage_rules():
    global DEMO_KNOWLEDGE_BASE
    conn = get_db_connection()
    
    if request.method == "GET":
        q = request.args.get("query", "").strip()
        if conn:
            try:
                cursor = conn.cursor(dictionary=True)
                if q:
                    pat = f"%{q}%"
                    cursor.execute("SELECT * FROM knowledge_base WHERE keyword LIKE %s OR official_term LIKE %s OR content LIKE %s ORDER BY id DESC", (pat, pat, pat))
                else:
                    cursor.execute("SELECT * FROM knowledge_base ORDER BY id DESC")
                rows = cursor.fetchall()
                cursor.close()
                conn.close()
                return jsonify({"status": "success", "data": rows, "count": len(rows)}), 200
            except Exception:
                if conn: conn.close()

        # Fallback
        res = DEMO_KNOWLEDGE_BASE
        if q:
            res = [r for r in res if q.lower() in r["keyword"].lower() or q.lower() in r["content"].lower() or q.lower() in r.get("official_term", "").lower()]
        return jsonify({"status": "success", "data": res, "count": len(res)}), 200

    elif request.method == "POST":
        data = request.get_json(silent=True) or {}
        kw = data.get("keyword", "").strip()
        ot = data.get("official_term", "").strip()
        ct = data.get("content", "").strip()
        doc = data.get("doc_name", "").strip() or "康寧大學校規.pdf"
        page = int(data.get("page", 1))
        url = data.get("url", "").strip() or "https://www.ukn.edu.tw/"

        if not kw or not ct:
            return jsonify({"detail": "關鍵字與內容解答為必填欄位"}), 400

        if conn:
            try:
                cursor = conn.cursor()
                sql = "INSERT INTO knowledge_base (keyword, official_term, content, doc_name, page, url) VALUES (%s, %s, %s, %s, %s, %s)"
                cursor.execute(sql, (kw, ot, ct, doc, page, url))
                conn.commit()
                new_id = cursor.lastrowid
                cursor.close()
                conn.close()
                return jsonify({"status": "success", "message": "校規新增成功！", "id": new_id}), 201
            except Exception:
                if conn: conn.close()

        # Fallback
        new_id = max([r["id"] for r in DEMO_KNOWLEDGE_BASE], default=0) + 1
        new_item = {
            "id": new_id,
            "keyword": kw,
            "official_term": ot,
            "content": ct,
            "doc_name": doc,
            "page": page,
            "url": url
        }
        DEMO_KNOWLEDGE_BASE.insert(0, new_item)
        return jsonify({"status": "success", "message": "校規新增成功 (示範模式)！", "id": new_id}), 201

@app.route("/api/rules/<int:rule_id>", methods=["PUT", "DELETE"])
def update_or_delete_rule(rule_id):
    global DEMO_KNOWLEDGE_BASE
    conn = get_db_connection()

    if request.method == "PUT":
        data = request.get_json(silent=True) or {}
        kw = data.get("keyword", "").strip()
        ot = data.get("official_term", "").strip()
        ct = data.get("content", "").strip()
        doc = data.get("doc_name", "").strip()
        page = int(data.get("page", 1))
        url = data.get("url", "").strip()

        if conn:
            try:
                cursor = conn.cursor()
                sql = """
                    UPDATE knowledge_base
                    SET keyword = %s, official_term = %s, content = %s, doc_name = %s, page = %s, url = %s
                    WHERE id = %s
                """
                cursor.execute(sql, (kw, ot, ct, doc, page, url, rule_id))
                conn.commit()
                cursor.close()
                conn.close()
                return jsonify({"status": "success", "message": "條文更新成功！"}), 200
            except Exception:
                if conn: conn.close()

        # Fallback
        for r in DEMO_KNOWLEDGE_BASE:
            if r["id"] == rule_id:
                if kw: r["keyword"] = kw
                if ot is not None: r["official_term"] = ot
                if ct: r["content"] = ct
                if doc: r["doc_name"] = doc
                if page: r["page"] = page
                if url: r["url"] = url
                return jsonify({"status": "success", "message": "條文更新成功 (示範模式)！"}), 200

        return jsonify({"detail": "找不到該條文 ID"}), 404

    elif request.method == "DELETE":
        if conn:
            try:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM knowledge_base WHERE id = %s", (rule_id,))
                conn.commit()
                cursor.close()
                conn.close()
                return jsonify({"status": "success", "message": "條文刪除成功！"}), 200
            except Exception:
                if conn: conn.close()

        # Fallback
        DEMO_KNOWLEDGE_BASE = [r for r in DEMO_KNOWLEDGE_BASE if r["id"] != rule_id]
        return jsonify({"status": "success", "message": "條文已自清單刪除！"}), 200

# ==========================================
# 8. 同義詞字典 CRUD API (/api/synonyms)
# ==========================================

@app.route("/api/synonyms", methods=["GET", "POST"])
def manage_synonyms():
    global DEMO_SYNONYMS
    conn = get_db_connection()

    if request.method == "GET":
        if conn:
            try:
                cursor = conn.cursor(dictionary=True)
                cursor.execute("SELECT synonym_id, user_keyword, official_term, category FROM synonym_dictionary ORDER BY synonym_id ASC")
                rows = cursor.fetchall()
                cursor.close()
                conn.close()
                return jsonify({"status": "success", "data": rows}), 200
            except Exception:
                if conn: conn.close()

        return jsonify({"status": "success", "data": DEMO_SYNONYMS}), 200

    elif request.method == "POST":
        data = request.get_json(silent=True) or {}
        uk = data.get("user_keyword", "").strip()
        ot = data.get("official_term", "").strip()
        cat = data.get("category", "綜合").strip()

        if not uk or not ot:
            return jsonify({"detail": "俗稱關鍵字與官方標準名稱為必填"}), 400

        if conn:
            try:
                cursor = conn.cursor()
                cursor.execute("INSERT INTO synonym_dictionary (user_keyword, official_term, category) VALUES (%s, %s, %s)", (uk, ot, cat))
                conn.commit()
                new_id = cursor.lastrowid
                cursor.close()
                conn.close()
                return jsonify({"status": "success", "message": "同義詞新增成功！", "id": new_id}), 201
            except Exception:
                if conn: conn.close()

        new_id = max([s["synonym_id"] for s in DEMO_SYNONYMS], default=0) + 1
        DEMO_SYNONYMS.append({
            "synonym_id": new_id,
            "user_keyword": uk,
            "official_term": ot,
            "category": cat
        })
        return jsonify({"status": "success", "message": "同義詞新增成功！", "id": new_id}), 201

@app.route("/api/synonyms/<int:synonym_id>", methods=["DELETE"])
def delete_synonym(synonym_id):
    global DEMO_SYNONYMS
    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM synonym_dictionary WHERE synonym_id = %s", (synonym_id,))
            conn.commit()
            cursor.close()
            conn.close()
            return jsonify({"status": "success", "message": "同義詞刪除成功！"}), 200
        except Exception:
            if conn: conn.close()

    DEMO_SYNONYMS = [s for s in DEMO_SYNONYMS if s["synonym_id"] != synonym_id]
    return jsonify({"status": "success", "message": "同義詞刪除成功！"}), 200

# ==========================================
# 9. 行政流程指引清單 API (/api/checklists)
# ==========================================

@app.route("/api/checklists", methods=["GET", "POST"])
def manage_checklists():
    global DEMO_CHECKLISTS
    conn = get_db_connection()

    if request.method == "GET":
        if conn:
            try:
                cursor = conn.cursor(dictionary=True)
                cursor.execute("SELECT * FROM checklist_items ORDER BY item_id ASC")
                rows = cursor.fetchall()
                for r in rows:
                    if isinstance(r.get("steps_json"), str):
                        try:
                            r["steps_json"] = json.loads(r["steps_json"])
                        except Exception:
                            r["steps_json"] = [r["steps_json"]]
                cursor.close()
                conn.close()
                return jsonify({"status": "success", "data": rows}), 200
            except Exception:
                if conn: conn.close()

        return jsonify({"status": "success", "data": DEMO_CHECKLISTS}), 200

    elif request.method == "POST":
        data = request.get_json(silent=True) or {}
        bname = data.get("business_name", "").strip()
        steps = data.get("steps_json", [])
        docs = data.get("required_docs", "").strip()
        hours = data.get("office_hours", "").strip()
        cat = data.get("category", "綜合").strip()

        if not bname or not steps:
            return jsonify({"detail": "業務名稱與步驟清單為必填"}), 400

        steps_str = json.dumps(steps, ensure_ascii=False)

        if conn:
            try:
                cursor = conn.cursor()
                sql = "INSERT INTO checklist_items (business_name, steps_json, required_docs, office_hours) VALUES (%s, %s, %s, %s)"
                cursor.execute(sql, (bname, steps_str, docs, hours))
                conn.commit()
                new_id = cursor.lastrowid
                cursor.close()
                conn.close()
                return jsonify({"status": "success", "message": "流程指引建立成功！", "id": new_id}), 201
            except Exception:
                if conn: conn.close()

        new_id = max([c["item_id"] for c in DEMO_CHECKLISTS], default=0) + 1
        DEMO_CHECKLISTS.append({
            "item_id": new_id,
            "business_name": bname,
            "category": cat,
            "steps_json": steps if isinstance(steps, list) else [steps],
            "required_docs": docs,
            "office_hours": hours
        })
        return jsonify({"status": "success", "message": "流程指引建立成功！", "id": new_id}), 201

# ==========================================
# 10. 課程地圖與修課/擋修檢核 API (/api/courses)
# ==========================================

@app.route("/api/courses", methods=["GET"])
def get_courses():
    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor(dictionary=True)
            sql = """
                SELECT 
                    c.course_id, c.course_name, c.credits, c.prerequisite_id, c.is_required,
                    p.course_name as prerequisite_name
                FROM course_map c
                LEFT JOIN course_map p ON c.prerequisite_id = p.course_id
                ORDER BY c.course_id ASC
            """
            cursor.execute(sql)
            rows = cursor.fetchall()
            cursor.close()
            conn.close()
            return jsonify({"status": "success", "data": rows}), 200
        except Exception:
            if conn: conn.close()

    return jsonify({"status": "success", "data": DEMO_COURSES}), 200

@app.route("/api/courses/check", methods=["POST"])
def check_course_prerequisites():
    """
    接收已修過之課程 ID 清單 (例如: ["CS101", "CS102"])
    回傳：
    - 已修得學分
    - 各課程解鎖/可修讀狀態
    - 擋修預警清單
    """
    data = request.get_json(silent=True) or {}
    passed_ids = set(data.get("passed_courses", []))

    all_courses = DEMO_COURSES

    # 計算統計
    total_passed_credits = 0
    required_passed_credits = 0
    elective_passed_credits = 0

    evaluated_courses = []

    for c in all_courses:
        cid = c["course_id"]
        is_passed = cid in passed_ids
        pre_id = c.get("prerequisite_id")
        
        # 判斷是否可修（如果沒有先修，或先修已通過）
        can_take = True
        missing_prereq = None
        if pre_id and pre_id not in passed_ids:
            can_take = False
            missing_prereq = {
                "prerequisite_id": pre_id,
                "prerequisite_name": c.get("prerequisite_name") or pre_id
            }

        if is_passed:
            total_passed_credits += c["credits"]
            if c["is_required"]:
                required_passed_credits += c["credits"]
            else:
                elective_passed_credits += c["credits"]

        evaluated_courses.append({
            **c,
            "is_passed": is_passed,
            "can_take": can_take,
            "is_blocked": not can_take and not is_passed,
            "missing_prerequisite": missing_prereq
        })

    return jsonify({
        "status": "success",
        "total_passed_credits": total_passed_credits,
        "required_passed_credits": required_passed_credits,
        "elective_passed_credits": elective_passed_credits,
        "graduation_threshold": 128,
        "progress_percent": round(min(100, (total_passed_credits / 128) * 100), 1),
        "courses": evaluated_courses
    }), 200

# ==========================================
# 11. 啟動 Flask 伺服器
# ==========================================

if __name__ == "__main__":
    os.makedirs("static", exist_ok=True)

    print("=" * 65)
    print("🚀 Smart UKN 康寧大學智慧校園全方位平台已啟動！")
    print("🌐 前台首頁與多功能門戶： http://127.0.0.1:8000")
    print("⚙️ 管理員控制台網址：   http://127.0.0.1:8000/admin")
    print("🔍 AI 智慧搜尋檢索 API: http://127.0.0.1:8000/api/search")
    print("🎓 課程地圖與擋修 API:  http://127.0.0.1:8000/api/courses")
    print("❤️ 服務與資料庫健康狀態: http://127.0.0.1:8000/api/health")
    print("=" * 65)

    app.run(host="0.0.0.0", port=8000, debug=True)