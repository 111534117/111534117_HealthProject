import mysql.connector

def seed_data():
    try:
        conn = mysql.connector.connect(
            host="127.0.0.1", user="root", password="root1234", database="smart_ukn", charset="utf8mb4"
        )
        cursor = conn.cursor()

        # 寫入知識庫測試資料
        sql_kb = """
            INSERT IGNORE INTO `knowledge_base` (`id`, `keyword`, `official_term`, `content`, `doc_name`, `page`, `url`) VALUES
            (1, '棄修', '停修', '關於「停修」的辦理規定：學生應於校曆規定之申請期限內提出申請，經導師及系所主管核章後送交教務處辦理。逾期不受理。', '康寧大學學生學則.pdf', 12, 'https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw'),
            (2, '英文抵免', '語言證照抵免', '關於「語言證照抵免」：凡通過全民英檢中高級或同等多益成績者，得於入學第一學期申請抵免大一英文課程。', '康寧大學抵免學分辦法.pdf', 5, 'https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw'),
            (3, '請假規定', '學生請假規定', '關於「學生請假」：病假需附三日內醫院證明，三天以上需經系主任核准，並於請假系統完成線上簽核。', '康寧大學學生請假規則.pdf', 3, 'https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw')
        """
        
        # 寫入同義詞字典測試資料
        sql_synonym = """
            INSERT IGNORE INTO `synonym_dictionary` (`synonym_id`, `user_keyword`, `official_term`, `category`) VALUES
            (1, '棄修', '停修', '課務'),
            (2, '二一', '學業退學', '學籍'),
            (3, '重修', '再次修習', '課務'),
            (4, '請假', '學生請假', '學務'),
            (5, '當掉', '成績不及格', '課務')
        """

        cursor.execute(sql_kb)
        cursor.execute(sql_synonym)
        conn.commit()
        
        print("✅ 測試資料 (seed_data) 寫入成功！")

    except mysql.connector.Error as err:
        print(f"❌ 寫入測試資料錯誤: {err}")
    finally:
        if 'cursor' in locals(): cursor.close()
        if 'conn' in locals() and conn.is_connected(): conn.close()

if __name__ == "__main__":
    seed_data()