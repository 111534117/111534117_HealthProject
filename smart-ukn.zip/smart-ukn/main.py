from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import os

app = FastAPI(title="Smart UKN API - Online Demo")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

SYNONYM_MOCK = {
    "棄修": "停修",
    "退選": "停修",
    "擋修": "先修科目未通過",
    "英文抵免": "語言證照抵免",
    "英檢抵免": "語言證照抵免",
    "病假": "學生請假規定",
}

class SearchQuery(BaseModel):
    query: str

@app.post("/api/search")
async def search_knowledge(data: SearchQuery):
    user_query = data.query.strip()

    if len(user_query) < 2:
        raise HTTPException(status_code=400, detail="搜尋關鍵字字數需至少為 2 個字")

    matched_official = SYNONYM_MOCK.get(user_query, None)
    is_synonym = matched_official is not None
    target_keyword = matched_official if is_synonym else user_query

    return {
        "status": "success",
        "is_synonym_matched": is_synonym,
        "official_term": matched_official,
        "search_term": target_keyword,
        "answer": f"關於「{target_keyword}」的辦理規定：學生應於校曆規定之申請期限內提出申請，經導師及系所主管核章後送交教務處辦理。逾期不受理。",
        "source_doc": "康寧大學學生學則第 15 條.pdf",
        "page_num": 12,
        "source_url": "https://www.ukn.edu.tw/p/412-1000-381.php?Lang=zh-tw",
        "checklist": [
            "登入教務系統填寫申請表單",
            "列印紙本表單並請導師簽章",
            "送交教務處課務組核備"
        ]
    }

os.makedirs("static", exist_ok=True)
app.mount("/", StaticFiles(directory="static", html=True), name="static")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)